package com.challenge.elevatorSystem.entities;

public enum tipoAscensor
{
	PUBLICO,
	CARGA	
}
