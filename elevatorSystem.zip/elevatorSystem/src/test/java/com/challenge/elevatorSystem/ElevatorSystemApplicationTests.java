package com.challenge.elevatorSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElevatorSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
